package com.example.rest_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
